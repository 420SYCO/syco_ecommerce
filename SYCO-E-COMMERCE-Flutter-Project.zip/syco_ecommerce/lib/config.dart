/// Business identity settings.
/// Replace the blank registration fields with verified business details before
/// issuing tax invoices. No GSTIN or drug licence number is fabricated here.
class Shop {
  static const name = 'SYCO E-COMMERCE';
  static const address = 'Business address not configured';
  static const gstin = 'Not configured';
  static const dl_no = 'Not configured';
  static const dl_no2 = 'Not configured';
  static const phone = '+91 91141 85757';
  // Odisha state code. Confirm the place of supply for each transaction.
  static const stateCode = '21';
  static const stateName = 'Odisha';
}
