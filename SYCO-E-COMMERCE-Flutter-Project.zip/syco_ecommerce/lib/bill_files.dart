import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/material.dart';
import 'db.dart';
import 'invoice_pdf.dart';
import 'drive_backup.dart';

class BillFiles {
  static Future<File> saveLocalPdf(int invoiceId) async {
    final doc = await InvoicePdf.build(invoiceId);
    final bytes = await doc.save();

    final dir = await getApplicationDocumentsDirectory();
    final billsDir = Directory('${dir.path}/SYCO E-COMMERCE');
    if (!await billsDir.exists()) {
      await billsDir.create(recursive: true);
    }

    final inv = (await (await DB.db).query('invoices', where: 'id=?', whereArgs: [invoiceId])).first;
    final name = _fileName(inv['invoice_no'] as String? ?? 'bill', inv['date'] as String);
    final file = File('${billsDir.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static Future<String?> backupToDrive(File file) => BackupService.uploadPdf(file);

  static Future<void> sharePdf(File file, {String? caption, Rect? origin}) async {
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      text: caption ?? 'Bill attached',
      subject: file.uri.pathSegments.last,
      sharePositionOrigin: origin,
    );
  }

  static Future<List<File>> listLocal() async {
    final dir = await getApplicationDocumentsDirectory();
    final billsDir = Directory('${dir.path}/SYCO E-COMMERCE');
    if (!await billsDir.exists()) return [];
    final files = await billsDir.list().where((e) => e is File && e.path.endsWith('.pdf')).cast<File>().toList();
    files.sort((a, b) => b.path.compareTo(a.path));
    return files;
  }

  static Future<File> ensureForInvoice(int invoiceId) async {
    final inv = (await (await DB.db).query('invoices', where: 'id=?', whereArgs: [invoiceId])).first;
    final name = _fileName(inv['invoice_no'] as String? ?? 'bill', inv['date'] as String);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/SYCO E-COMMERCE/$name');
    if (await file.exists()) return file;
    return saveLocalPdf(invoiceId);
  }

  static String _fileName(String no, String isoDate) {
    final d = DateTime.parse(isoDate);
    final dd = d.day.toString().padLeft(2, '0');
    final mm = d.month.toString().padLeft(2, '0');
    return '${no}_${dd}${mm}${d.year}.pdf';
  }
}