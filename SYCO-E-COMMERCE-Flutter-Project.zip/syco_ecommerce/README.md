# SYCO E-COMMERCE — Flutter Android project

This package contains the supplied Flutter application source plus the missing report and PDF-sharing modules, app artwork, and a GitHub Actions Android release workflow.

## Build an APK with GitHub

1. Create a GitHub repository and upload the contents of this folder to its root (not the folder itself).
2. Commit to the `main` branch.
3. Open the repository's **Actions** tab and select **Build SYCO E-COMMERCE APK**.
4. Run the workflow, or let the push trigger it. When it succeeds, download the `SYCO-E-COMMERCE-APK` artifact from the run summary and extract the ZIP.

The APK is at `app-release.apk` inside the artifact.

## Business details that must be completed

`lib/config.dart` intentionally does not invent regulated or tax identifiers. Before issuing real invoices, replace the following with verified details:

- Registered business name and complete address
- GSTIN (if registered)
- Both applicable drug licence numbers
- Confirm the state of registration and tax configuration

The app is configured with Odisha's state code `21` because the provided context indicates Odisha. Verify that this matches the actual registered place of business. The supplied contact number and email are retained from the original source files; verify that they belong to the business before publishing.

## Google Drive backup

The Drive backup feature requires an Android OAuth client configured in Google Cloud for the final Android application ID (`com.syco.syco_ecommerce`) and the signing certificate SHA-1. Without this setup, local billing and PDF generation can still be used, but Google sign-in/Drive backup may not authenticate.

## Important release notes

- New installations no longer receive fake sample medicines or stock quantities.
- GSTR-1 export is shared as a CSV file, not mislabeled as a PDF.
- WhatsApp invoice sharing opens Android's share sheet; the user selects WhatsApp if installed.
- This is a generated unsigned release APK. For Play Store distribution or controlled updates, configure a private upload keystore and sign the release build.
- Validate GST treatment, invoice numbering, stock movements, expiry handling, and all business/legal particulars with a qualified accountant/pharmacist before using it for live pharmaceutical billing. This project is not a substitute for regulatory or tax compliance review.
