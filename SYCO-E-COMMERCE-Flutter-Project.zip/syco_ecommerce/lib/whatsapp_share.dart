import 'dart:io';
import 'package:share_plus/share_plus.dart';

/// Shares a generated invoice PDF using Android's native share sheet.
/// The user chooses WhatsApp (or another installed app) from the sheet.
class WhatsAppShare {
  static Future<void> sendPdfViaShareSheet(
    File file, {
    String? caption,
  }) async {
    if (!await file.exists()) {
      throw StateError('Invoice PDF does not exist: ${file.path}');
    }
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      text: caption ?? 'Invoice from SYCO E-COMMERCE',
      subject: 'SYCO E-COMMERCE invoice',
    );
  }
}
