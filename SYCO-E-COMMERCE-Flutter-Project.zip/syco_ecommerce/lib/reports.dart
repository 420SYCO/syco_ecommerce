import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'db.dart';
import 'payments.dart';

final _money = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);

class LedgerListScreen extends StatefulWidget {
  const LedgerListScreen({super.key});
  @override
  State<LedgerListScreen> createState() => _LedgerListScreenState();
}

class _LedgerListScreenState extends State<LedgerListScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  @override
  void initState() { super.initState(); _future = Payments.ledgerSummary(); }
  Future<void> _reload() async => setState(() => _future = Payments.ledgerSummary());

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Party Ledger'), actions: [
      IconButton(tooltip: 'Record payment', icon: const Icon(Icons.add_card), onPressed: () async {
        final saved = await showDialog<bool>(context: context, builder: (_) => const PaymentDialog());
        if (saved == true) _reload();
      }),
    ]),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text('Could not load ledger: ${snapshot.error}'));
        final rows = snapshot.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('No party transactions yet.'));
        return RefreshIndicator(onRefresh: _reload, child: ListView.separated(
          padding: const EdgeInsets.all(12), itemCount: rows.length,
          separatorBuilder: (_, __) => const SizedBox(height: 6),
          itemBuilder: (context, index) {
            final row = rows[index];
            final amount = (row['outstanding'] as num?)?.toDouble() ?? 0;
            final aging = row['aging'] as Map<String, double>? ?? {};
            return Card(child: ExpansionTile(
              title: Text('${row['party'] ?? 'Unnamed party'}', style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('Net balance: ${_money.format(amount)}'),
              children: [Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 12), child: Wrap(spacing: 12, runSpacing: 8, children: aging.entries.map((e) => Chip(label: Text('${e.key} days: ${_money.format(e.value)}'))).toList()))],
            ));
          },
        ));
      },
    ),
  );
}

class ExpiryScreen extends StatefulWidget {
  const ExpiryScreen({super.key});
  @override
  State<ExpiryScreen> createState() => _ExpiryScreenState();
}

class _ExpiryScreenState extends State<ExpiryScreen> {
  late Future<List<Map<String, Object?>>> _future;
  @override
  void initState() { super.initState(); _future = _load(); }
  Future<List<Map<String, Object?>>> _load() async {
    final d = await DB.db;
    return d.rawQuery('''SELECT b.id, p.name AS product_name, b.batch_no, b.expiry, b.qty
      FROM batches b LEFT JOIN products p ON p.id=b.product_id
      WHERE b.qty > 0 AND b.expiry IS NOT NULL AND b.expiry <> ''
      ORDER BY b.expiry ASC''');
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Expiry Report')),
    body: FutureBuilder<List<Map<String, Object?>>>(future: _future, builder: (context, s) {
      if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (s.hasError) return Center(child: Text('Could not load expiry report: ${s.error}'));
      final rows = s.data ?? [];
      if (rows.isEmpty) return const Center(child: Text('No active batches found.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (context, i) {
        final r = rows[i];
        final raw = (r['expiry'] ?? '').toString();
        DateTime? expiry;
        try { expiry = DateTime.parse(raw.length == 7 ? '$raw-01' : raw); } catch (_) {}
        final expired = expiry != null && expiry.isBefore(DateTime(DateTime.now().year, DateTime.now().month, 1));
        return Card(child: ListTile(
          leading: Icon(expired ? Icons.warning_amber : Icons.event_available, color: expired ? Colors.red : Colors.green),
          title: Text('${r['product_name'] ?? 'Unknown product'}'),
          subtitle: Text('Batch: ${r['batch_no'] ?? '-'}  •  Expiry: $raw'),
          trailing: Text('Qty ${r['qty'] ?? 0}'),
        ));
      });
    }),
  );
}

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});
  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  late Future<List<Map<String, Object?>>> _future;
  @override
  void initState() { super.initState(); _future = _load(); }
  Future<List<Map<String, Object?>>> _load() async {
    final d = await DB.db;
    return d.rawQuery('''SELECT p.id, p.name, p.hsn, p.unit, COALESCE(SUM(b.qty), 0) AS stock,
      COUNT(b.id) AS batch_count FROM products p LEFT JOIN batches b ON b.product_id=p.id
      GROUP BY p.id ORDER BY p.name''');
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Stock Report')),
    body: FutureBuilder<List<Map<String, Object?>>>(future: _future, builder: (context, s) {
      if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (s.hasError) return Center(child: Text('Could not load stock: ${s.error}'));
      final rows = s.data ?? [];
      if (rows.isEmpty) return const Center(child: Text('No products available.'));
      return ListView.separated(padding: const EdgeInsets.all(12), itemCount: rows.length,
        separatorBuilder: (_, __) => const SizedBox(height: 4),
        itemBuilder: (context, i) { final r = rows[i]; return Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.medication)),
          title: Text('${r['name']}'), subtitle: Text('HSN: ${r['hsn'] ?? '-'}  •  Batches: ${r['batch_count']}'),
          trailing: Text('${r['stock'] ?? 0} ${r['unit'] ?? 'PCS'}', style: const TextStyle(fontWeight: FontWeight.bold)),
        )); },
      );
    }),
  );
}
