import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Contact {
  static const email     = 'atalkumarmallik3@gmail.com';
  static const phone     = '+91 91141 85757';
  static const phoneRaw  = '919114185757';
  static const whatsappMessage = 'Hello SYCO E-COMMERCE, I need help with the billing app.';
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Future<void> _openWhatsApp(BuildContext context) async {
    final url = Uri.parse('https://wa.me/${Contact.phoneRaw}?text=${Uri.encodeComponent(Contact.whatsappMessage)}');
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open WhatsApp.')));
    }
  }

  Future<void> _call() async => await launchUrl(Uri.parse('tel:${Contact.phoneRaw}'));
  Future<void> _email() async => await launchUrl(Uri.parse('mailto:${Contact.email}?subject=SYCO E-COMMERCE - Query'));

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help & Contact')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          elevation: 2,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Image.asset('assets/logo.png', height: 80, width: double.infinity, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Icon(Icons.local_pharmacy, size: 80, color: Color(0xFF0A7A3B))),
              const SizedBox(height: 12),
              const Text('SYCO E-COMMERCE', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF25D366)),
            onPressed: () => _openWhatsApp(c),
            icon: const Icon(Icons.chat_bubble),
            label: const Text('Message me on WhatsApp', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(height: 12),
        Card(child: ListTile(leading: const Icon(Icons.call), title: const Text('Call'), subtitle: const Text(Contact.phone), onTap: _call)),
        Card(child: ListTile(leading: const Icon(Icons.email), title: const Text('Email'), subtitle: const Text(Contact.email), onTap: _email)),
      ]),
    );
  }
}