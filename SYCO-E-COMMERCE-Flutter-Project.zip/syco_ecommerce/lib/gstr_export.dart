import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import 'db.dart';
import 'config.dart';

class Gstr1Export {
  static Future<void> share(DateTime from, DateTime to) async {
    final d = await DB.db;
    final df = DateFormat('dd-MM-yyyy');
    final invoices = await d.query('invoices', where: "type='sale' AND date >= ? AND date < ?", whereArgs: [from.toIso8601String(), to.add(const Duration(days: 1)).toIso8601String()]);
    
    final buf = StringBuffer();
    buf.writeln('GSTIN of Supplier:,${Shop.gstin}\nPeriod:,${df.format(from)} to ${df.format(to)}\n');
    buf.writeln('GSTIN,Party,Invoice No,Date,Total,Place of Supply,Rate,Taxable,Tax');
    
    for (final inv in invoices) {
      final items = await d.query('invoice_items', where: 'invoice_id=?', whereArgs: [inv['id']]);
      for (final it in items) {
        buf.writeln('"${inv['party_gstin']}","${inv['party_name']}","${inv['invoice_no']}","${df.format(DateTime.parse(inv['date'] as String))}","${inv['total']}","${inv['place_of_supply']}","${it['gst_rate']}","${it['taxable']}","${(it['cgst'] as num)+(it['sgst'] as num)}"');
      }
    }
    
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/GSTR1_${df.format(from)}.csv');
    await file.writeAsString(buf.toString());
    await Share.shareXFiles([XFile(file.path, mimeType: 'text/csv')], text: 'GSTR-1 sales data export');
  }
}