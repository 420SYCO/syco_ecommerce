import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'syco.db');
    _db = await openDatabase(path, version: 5, onCreate: _create, onUpgrade: _upgrade);
    return _db!;
  }

  static Future close() async {
    await _db?.close();
    _db = null;
  }

  static Future _create(Database d, int v) async {
    await d.execute('''CREATE TABLE products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, hsn TEXT, gst_rate REAL DEFAULT 12, unit TEXT DEFAULT 'PCS')''');
    await d.execute('''CREATE TABLE batches(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER, batch_no TEXT, expiry TEXT,
      purchase_rate REAL, mrp REAL, qty REAL DEFAULT 0)''');
    await d.execute('''CREATE TABLE parties(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT, type TEXT, gstin TEXT, phone TEXT, state TEXT DEFAULT 'Maharashtra')''');
    await d.execute('''CREATE TABLE invoices(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT, type TEXT, party_name TEXT, date TEXT,
      subtotal REAL, discount REAL, taxable REAL,
      cgst REAL, sgst REAL, igst REAL, total REAL,
      party_gstin TEXT, party_state_code TEXT, place_of_supply TEXT,
      is_b2b INTEGER DEFAULT 0, party_phone TEXT)''');
    await d.execute('''CREATE TABLE invoice_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER,
      product_id INTEGER, product_name TEXT, batch_id INTEGER,
      batch_no TEXT, expiry TEXT, hsn TEXT,
      qty REAL, free_qty REAL, rate REAL, discount_pct REAL,
      taxable REAL, gst_rate REAL, cgst REAL, sgst REAL, igst REAL, amount REAL)''');
    await d.execute('''CREATE TABLE payments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      party_name TEXT NOT NULL, date TEXT NOT NULL, type TEXT NOT NULL,
      amount REAL NOT NULL, mode TEXT, reference TEXT, note TEXT)''');
    await d.execute('''CREATE TABLE settings(
      key TEXT PRIMARY KEY, value TEXT)''');
  }

  static Future _upgrade(Database d, int oldV, int newV) async {
    if (oldV < 2) {
      await d.execute("ALTER TABLE invoices ADD COLUMN party_gstin TEXT");
      await d.execute("ALTER TABLE invoices ADD COLUMN party_state_code TEXT");
      await d.execute("ALTER TABLE invoices ADD COLUMN place_of_supply TEXT");
      await d.execute("ALTER TABLE invoices ADD COLUMN igst REAL DEFAULT 0");
      await d.execute("ALTER TABLE invoices ADD COLUMN is_b2b INTEGER DEFAULT 0");
    }
    if (oldV < 3) {
      await d.execute('''CREATE TABLE IF NOT EXISTS payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        party_name TEXT NOT NULL, date TEXT NOT NULL, type TEXT NOT NULL,
        amount REAL NOT NULL, mode TEXT, reference TEXT, note TEXT)''');
    }
    if (oldV < 4) {
      await d.execute("ALTER TABLE invoices ADD COLUMN party_phone TEXT");
    }
    if (oldV < 5) {
      await d.execute('''CREATE TABLE IF NOT EXISTS settings(
        key TEXT PRIMARY KEY, value TEXT)''');
    }
  }

  // Deliberately do not insert sample medicines or stock into a live billing database.
  // A new installation starts empty; the operator adds verified inventory.
  static Future<void> seedIfEmpty() async {
    await db;
  }

  static Future<List<Map<String, Object?>>> products() async => (await db).query('products', orderBy: 'name');

  static Future<List<Map<String, Object?>>> batchesForSale(int pid) async =>
      (await db).query('batches', where: 'product_id=? AND qty>0', whereArgs: [pid], orderBy: 'expiry ASC');

  static Future<String> nextInvoiceNo(String type) async {
    final d = await db;
    final r = await d.rawQuery('SELECT COUNT(*) c FROM invoices WHERE type=?', [type]);
    final n = ((r.first['c'] as int?) ?? 0) + 1;
    return '${type == 'sale' ? 'S' : 'P'}-${n.toString().padLeft(4, '0')}';
  }

  static Future<Map<String, int>> counts() async {
    final d = await db;
    Future<int> c(String t) async => Sqflite.firstIntValue(await d.rawQuery('SELECT COUNT(*) FROM $t')) ?? 0;
    return {'products': await c('products'), 'batches': await c('batches'), 'invoices': await c('invoices')};
  }

  static Future<bool> getShowLogo() async {
    final d = await db;
    final res = await d.query('settings', where: 'key = ?', whereArgs: ['show_logo']);
    if (res.isEmpty) return true;
    return res.first['value'] == '1';
  }

  static Future<void> setShowLogo(bool value) async {
    final d = await db;
    await d.insert('settings', {'key': 'show_logo', 'value': value ? '1' : '0'}, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}