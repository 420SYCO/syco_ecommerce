import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import 'drive_backup.dart';
import 'bill_files.dart';
import 'whatsapp_share.dart';
import 'contact.dart';
import 'reports.dart';
import 'gstr_export.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _migrateFromOldName();
  await BackupService.init();
  await DB.seedIfEmpty();
  runApp(const App());
}

Future<void> _migrateFromOldName() async {
  final dir = await getDatabasesPath();
  final oldDb = File('$dir/pharma.db');
  final newDb = File('$dir/syco.db');
  if (await oldDb.exists() && !await newDb.exists()) {
    for (final suffix in ['', '-wal', '-shm']) {
      final src = File('$dir/pharma.db$suffix');
      if (await src.exists()) await src.rename('$dir/syco.db$suffix');
    }
  }
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => const MaterialApp(title: 'SYCO E-COMMERCE', home: HomeScreen(), debugShowCheckedModeBanner: false);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Future<Map<String, int>>? _counts;
  @override
  void initState() { super.initState(); _refresh(); }
  void _refresh() => setState(() => _counts = DB.counts());

  Future<void> _backupNow() async {
    final name = await BackupService.backup();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(name != null ? 'Backed up: $name' : 'Sign in to Google Drive first')));
    setState(() {});
  }

  Future<void> _restore() async {
    final done = await BackupService.restoreLatest();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(done ? 'Restored from Drive' : 'No backup found')));
    _refresh();
  }

  Future<void> _showSettings() async {
    bool showLogo = await DB.getShowLogo();
    if (!mounted) return;
    showDialog(context: context, builder: (c) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      title: const Text('App Settings'),
      content: SwitchListTile(
        title: const Text('Show Logo on Bill'),
        value: showLogo,
        onChanged: (val) async { await DB.setShowLogo(val); setDialogState(() => showLogo = val); },
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close'))],
    )));
  }

  @override
  Widget build(BuildContext c) {
    final email = BackupService.email;
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Image.asset('assets/logo.png', height: 30, width: 30, errorBuilder: (_, __, ___) => const Icon(Icons.local_pharmacy)),
          const SizedBox(width: 8), const Text('SYCO E-COMMERCE'),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.settings), onPressed: _showSettings),
          IconButton(icon: const Icon(Icons.help_outline), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactScreen()))),
          IconButton(icon: const Icon(Icons.backup), onPressed: _backupNow),
        ],
      ),
      body: FutureBuilder<Map<String, int>>(
        future: _counts,
        builder: (c, s) {
          final d = s.data ?? {'products': 0, 'batches': 0, 'invoices': 0};
          return ListView(padding: const EdgeInsets.all(16), children: [
            Card(child: ListTile(leading: const Icon(Icons.cloud), title: Text(email == null ? 'Drive: not connected' : 'Drive: $email'), trailing: TextButton(onPressed: () async { if (email == null) await BackupService.signIn(); else await BackupService.signOut(); setState(() {}); }, child: Text(email == null ? 'Sign in' : 'Sign out')))),
            const SizedBox(height: 8),
            Row(children: [_stat('Products', d['products']!), _stat('Batches', d['batches']!), _stat('Bills', d['invoices']!)]),
            const SizedBox(height: 12),
            InkWell(
              onTap: () => launchUrl(Uri.parse('https://wa.me/${Contact.phoneRaw}?text=${Uri.encodeComponent(Contact.whatsappMessage)}'), mode: LaunchMode.externalApplication),
              child: Container(
                padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF25D366), borderRadius: BorderRadius.circular(12)),
                child: const Row(children: [Icon(Icons.chat, color: Colors.white), SizedBox(width: 12), Text('Need help? Message on WhatsApp', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))]),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceScreen(isPurchase: false))).then((_) => _refresh()), icon: const Icon(Icons.receipt_long), label: const Text('New Sale Bill')),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceScreen(isPurchase: true))).then((_) => _refresh()), icon: const Icon(Icons.shopping_cart), label: const Text('New Purchase Bill')),
            const SizedBox(height: 16), const Divider(),
            const Text('Reports', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _report('Ledger', Icons.account_balance_wallet, () => const LedgerListScreen()),
              _report('Expiry', Icons.warning_amber, () => const ExpiryScreen()),
              _report('Stock', Icons.inventory_2, () => const StockScreen()),
              _actionReport('GSTR-1', Icons.table_chart, () => Gstr1Export.share(DateTime.now().subtract(const Duration(days: 30)), DateTime.now())),
            ]),
          ]);
        },
      ),
    );
  }

  Widget _stat(String label, int v) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text('$v', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(label)]))));
  Widget _report(String label, IconData icon, Widget Function() builder) => SizedBox(width: 110, height: 80, child: OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => builder())), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon), Text(label)])));
  Widget _actionReport(String label, IconData icon, VoidCallback action) => SizedBox(width: 110, height: 80, child: OutlinedButton(onPressed: action, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon), Text(label)])));
}

class Item {
  int productId = 0; String productName = ''; int? batchId; String batchNo = ''; String expiry = ''; String hsn = '';
  double qty = 0, freeQty = 0, rate = 0, discountPct = 0, gstRate = 0;
  double get gross => qty * rate;
  double get discount => gross * discountPct / 100;
  double get taxable => gross - discount;
  double get gst => taxable * gstRate / 100;
  double get cgst => gst / 2;
  double get sgst => gst / 2;
  double get amount => taxable + gst;
}

class InvoiceScreen extends StatefulWidget {
  final bool isPurchase;
  const InvoiceScreen({super.key, required this.isPurchase});
  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  final _party = TextEditingController();
  final _partyPhone = TextEditingController();
  final _partyGstin = TextEditingController();
  final List<Item> _items = [];
  bool _saving = false;

  double get subtotal => _items.fold(0, (a, i) => a + i.gross);
  double get discount => _items.fold(0, (a, i) => a + i.discount);
  double get taxable => _items.fold(0, (a, i) => a + i.taxable);
  double get cgst => _items.fold(0, (a, i) => a + i.cgst);
  double get sgst => _items.fold(0, (a, i) => a + i.sgst);
  double get total => taxable + cgst + sgst;

  Future<void> _save() async {
    if (_items.isEmpty) return;
    setState(() => _saving = true);
    final d = await DB.db;
    final type = widget.isPurchase ? 'purchase' : 'sale';
    final no = await DB.nextInvoiceNo(type);

    final invId = await d.insert('invoices', {
      'invoice_no': no, 'type': type, 'party_name': _party.text.trim(),
      'date': DateTime.now().toIso8601String(), 'subtotal': subtotal, 'discount': discount,
      'taxable': taxable, 'cgst': cgst, 'sgst': sgst, 'igst': 0, 'total': total,
      'party_gstin': _partyGstin.text.trim(), 'party_phone': _partyPhone.text.trim(),
    });

    for (final i in _items) {
      await d.insert('invoice_items', {
        'invoice_id': invId, 'product_id': i.productId, 'product_name': i.productName, 'batch_id': i.batchId,
        'batch_no': i.batchNo, 'expiry': i.expiry, 'hsn': i.hsn, 'qty': i.qty, 'free_qty': i.freeQty, 'rate': i.rate,
        'discount_pct': i.discountPct, 'taxable': i.taxable, 'gst_rate': i.gstRate, 'cgst': i.cgst, 'sgst': i.sgst, 'igst': 0, 'amount': i.amount,
      });
      if (widget.isPurchase) {
        final ex = await d.query('batches', where: 'product_id=? AND batch_no=?', whereArgs: [i.productId, i.batchNo]);
        if (ex.isEmpty) {
          await d.insert('batches', {'product_id': i.productId, 'batch_no': i.batchNo, 'expiry': i.expiry, 'purchase_rate': i.rate, 'mrp': i.rate * 1.5, 'qty': i.qty + i.freeQty});
        } else {
          await d.rawUpdate('UPDATE batches SET qty = qty + ? WHERE id=?', [i.qty + i.freeQty, ex.first['id']]);
        }
      } else {
        await d.rawUpdate('UPDATE batches SET qty = qty - ? WHERE id=?', [i.qty + i.freeQty, i.batchId]);
      }
    }

    File? pdfFile;
    try { pdfFile = await BillFiles.saveLocalPdf(invId); } catch (e) { debugPrint('PDF err: $e'); }
    await BackupService.backup();
    if (pdfFile != null) await BillFiles.backupToDrive(pdfFile);

    if (!mounted) return;
    setState(() => _saving = false);
    
    showDialog(context: context, builder: (c) => AlertDialog(
      title: Text('Bill $no saved'),
      actions: [
        TextButton(onPressed: () { Navigator.pop(c); Navigator.pop(context); }, child: const Text('Done')),
        FilledButton(onPressed: () async {
          Navigator.pop(c);
          if (pdfFile != null) await WhatsAppShare.sendPdfViaShareSheet(pdfFile, caption: 'Bill $no from SYCO E-COMMERCE');
          if (mounted) Navigator.pop(context);
        }, child: const Text('Share PDF')),
      ],
    ));
  }

  @override
  Widget build(BuildContext c) {
    final f = NumberFormat('#,##0.00');
    return Scaffold(
      appBar: AppBar(title: Text(widget.isPurchase ? 'Purchase Bill' : 'Sale Bill'), actions: [IconButton(icon: const Icon(Icons.save), onPressed: _saving ? null : _save)]),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(8), child: TextField(controller: _party, decoration: const InputDecoration(labelText: 'Party Name'))),
        Padding(padding: const EdgeInsets.all(8), child: TextField(controller: _partyPhone, decoration: const InputDecoration(labelText: 'Phone Number'))),
        Expanded(child: ListView.builder(itemCount: _items.length, itemBuilder: (c, i) => Card(child: ListTile(title: Text(_items[i].productName), subtitle: Text('Qty: ${_items[i].qty} | Total: ${f.format(_items[i].amount)}'), trailing: IconButton(icon: const Icon(Icons.delete), onPressed: () => setState(() => _items.removeAt(i))))))),
        SafeArea(child: Container(padding: const EdgeInsets.all(12), child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Total'), Text(f.format(total), style: const TextStyle(fontWeight: FontWeight.bold))]),
          FilledButton(onPressed: () async {
            final it = await showDialog<Item>(context: context, builder: (_) => const ItemDialog());
            if (it != null) setState(() => _items.add(it));
          }, child: const Text('+ Add Item')),
        ]))),
      ]),
    );
  }
}

class ItemDialog extends StatefulWidget {
  const ItemDialog({super.key});
  @override
  State<ItemDialog> createState() => _ItemDialogState();
}

class _ItemDialogState extends State<ItemDialog> {
  List<Map<String, Object?>> _products = [];
  Map<String, Object?>? _product;
  final _qty = TextEditingController(text: '1');
  final _rate = TextEditingController();

  @override
  void initState() { super.initState(); DB.products().then((p) => setState(() => _products = p)); }

  @override
  Widget build(BuildContext c) => AlertDialog(
    title: const Text('Add Item'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      DropdownButtonFormField<Map<String, Object?>>(value: _product, items: _products.map((p) => DropdownMenuItem(value: p, child: Text(p['name'] as String))).toList(), onChanged: (p) => setState(() => _product = p)),
      TextField(controller: _qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Qty')),
      TextField(controller: _rate, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Rate')),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () {
      if (_product == null) return;
      final item = Item()..productId = _product!['id'] as int..productName = _product!['name'] as String..qty = double.tryParse(_qty.text) ?? 1..rate = double.tryParse(_rate.text) ?? 0..gstRate = (_product!['gst_rate'] as num).toDouble();
      Navigator.pop(context, item);
    }, child: const Text('Add'))],
  );
}