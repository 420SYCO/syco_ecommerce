import 'dart:io';
import 'dart:typed_data';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'db.dart';

class _AuthClient extends http.BaseClient {
  final Map<String, String> headers;
  final _inner = http.Client();
  _AuthClient(this.headers);
  @override
  Future<http.StreamedResponse> send(http.BaseRequest r) => _inner.send(r..headers.addAll(headers));
}

class BackupService {
  static final _signIn = GoogleSignIn(scopes: [
    drive.DriveApi.driveAppdataScope,
    drive.DriveApi.driveFileScope,
  ]);
  static GoogleSignInAccount? _account;

  static String? get email => _account?.email;

  static Future<void> init() async {
    _account ??= await _signIn.signInSilently();
  }

  static Future<bool> signIn() async {
    _account = await _signIn.signIn();
    return _account != null;
  }

  static Future<void> signOut() async {
    await _signIn.signOut();
    _account = null;
  }

  static Future<drive.DriveApi?> _api() async {
    _account ??= await _signIn.signInSilently();
    if (_account == null) return null;
    return drive.DriveApi(_AuthClient(await _account!.authHeaders));
  }

  static Future<String?> backup() async {
    final api = await _api();
    if (api == null) return null;
    await (await DB.db).rawQuery('PRAGMA wal_checkpoint(FULL)');
    final file = File(p.join(await getDatabasesPath(), 'syco.db'));
    final name = 'syco_${DateTime.now().millisecondsSinceEpoch}.db';
    await api.files.create(
      drive.File()..name = name..parents = ['appDataFolder'],
      uploadMedia: drive.Media(file.openRead(), await file.length()),
    );
    await _prune(api);
    return name;
  }

  static Future<void> _prune(drive.DriveApi api) async {
    final res = await api.files.list(spaces: 'appDataFolder', orderBy: 'createdTime desc', pageSize: 100);
    final files = res.files ?? [];
    for (final f in files.skip(5)) {
      try { await api.files.delete(f.id!); } catch (_) {}
    }
  }

  static Future<bool> restoreLatest() async {
    final api = await _api();
    if (api == null) return false;
    final res = await api.files.list(spaces: 'appDataFolder', orderBy: 'createdTime desc', pageSize: 1);
    final files = res.files ?? [];
    if (files.isEmpty) return false;

    final media = await api.files.get(files.first.id!, downloadOptions: drive.DownloadOptions.fullMedia) as drive.Media;
    final builder = BytesBuilder();
    await for (final chunk in media.stream) { builder.add(chunk); }

    await DB.close();
    final path = p.join(await getDatabasesPath(), 'syco.db');
    for (final suffix in ['', '-wal', '-shm']) {
      final f = File('$path$suffix');
      if (await f.exists()) await f.delete();
    }
    await File(path).writeAsBytes(builder.toBytes(), flush: true);
    await DB.db;
    return true;
  }

  static Future<String?> uploadPdf(File pdfFile) async {
    final api = await _api();
    if (api == null) return null;
    final folderId = await _getOrCreateBillsFolder(api);
    final name = pdfFile.path.split(Platform.pathSeparator).last;

    final existing = await api.files.list(q: "name='${_esc(name)}' and '$folderId' in parents and trashed=false", spaces: 'drive', pageSize: 1);
    if (existing.files != null && existing.files!.isNotEmpty) {
      final updated = await api.files.update(drive.File(), existing.files!.first.id!, uploadMedia: drive.Media(pdfFile.openRead(), pdfFile.lengthSync()));
      return updated.id;
    }
    final created = await api.files.create(drive.File()..name = name..parents = [folderId], uploadMedia: drive.Media(pdfFile.openRead(), pdfFile.lengthSync()));
    return created.id;
  }

  static Future<String> _getOrCreateBillsFolder(drive.DriveApi api) async {
    final res = await api.files.list(q: "mimeType='application/vnd.google-apps.folder' and name='SYCO E-COMMERCE' and trashed=false", spaces: 'drive', pageSize: 1);
    if (res.files != null && res.files!.isNotEmpty) return res.files!.first.id!;
    final folder = await api.files.create(drive.File()..name = 'SYCO E-COMMERCE'..mimeType = 'application/vnd.google-apps.folder');
    return folder.id!;
  }

  static String _esc(String s) => s.replaceAll("'", r"\'");
}