import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart';
import 'db.dart';
import 'config.dart';
import 'contact.dart';

class InvoicePdf {
  static Future<pw.MemoryImage?> _loadLogo() async {
    try {
      final data = await rootBundle.load('assets/logo.png');
      return pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) { return null; }
  }

  static Future<pw.Document> build(int invoiceId) async {
    final d = await DB.db;
    final inv = (await d.query('invoices', where: 'id=?', whereArgs: [invoiceId])).first;
    final items = await d.query('invoice_items', where: 'invoice_id=?', whereArgs: [invoiceId]);
    final isPurchase = inv['type'] == 'purchase';
    final isIgst = ((inv['igst'] as num?) ?? 0) > 0;
    
    final showLogo = await DB.getShowLogo();
    final logo = showLogo ? await _loadLogo() : null;

    final doc = pw.Document();
    final df = DateFormat('dd-MM-yyyy');

    pw.Widget h(String t) => pw.Padding(padding: const pw.EdgeInsets.all(3), child: pw.Text(t, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold)));
    pw.Widget c(String t, {pw.Alignment? align}) => pw.Padding(padding: const pw.EdgeInsets.all(3), child: pw.Text(t, style: const pw.TextStyle(fontSize: 7), textAlign: align == pw.Alignment.centerRight ? pw.TextAlign.right : pw.TextAlign.left));

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(20),
      header: (ctx) => pw.Container(
        padding: const pw.EdgeInsets.only(bottom: 6),
        decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(width: 1))),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Expanded(
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              if (logo != null)
                pw.Image(logo, height: 40, fit: pw.BoxFit.contain)
              else
                pw.Text(Shop.name, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text(Shop.address, style: const pw.TextStyle(fontSize: 8)),
              pw.Text('GSTIN: ${Shop.gstin}   State: ${Shop.stateName} (${Shop.stateCode})', style: const pw.TextStyle(fontSize: 8)),
              pw.Text('DL No: ${Shop.dl_no} / ${Shop.dl_no2}', style: const pw.TextStyle(fontSize: 8)),
              pw.Text('Ph: ${Shop.phone}', style: const pw.TextStyle(fontSize: 8)),
            ]),
          ),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
            pw.Text(isPurchase ? 'PURCHASE BILL' : 'TAX INVOICE', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
            pw.Text('No: ${inv['invoice_no']}', style: const pw.TextStyle(fontSize: 8)),
            pw.Text('Date: ${df.format(DateTime.parse(inv['date'] as String))}', style: const pw.TextStyle(fontSize: 8)),
          ]),
        ]),
      ),
      footer: (ctx) => pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text('For ${Shop.name}', style: const pw.TextStyle(fontSize: 8)),
        pw.Text('Page ${ctx.pageNumber}/${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 8)),
      ]),
      build: (ctx) => [
        pw.SizedBox(height: 6),
        pw.Container(
          padding: const pw.EdgeInsets.all(5),
          decoration: pw.BoxDecoration(border: pw.Border.all(width: 0.7)),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text(isPurchase ? 'Supplier:' : 'Billed to:', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
            pw.Text((inv['party_name'] as String?) ?? '-', style: const pw.TextStyle(fontSize: 9)),
            if ((inv['party_gstin'] as String?)?.isNotEmpty == true)
              pw.Text('GSTIN: ${inv['party_gstin']}', style: const pw.TextStyle(fontSize: 8)),
            pw.Text('Place of Supply: ${inv['place_of_supply'] ?? '${Shop.stateName} (${Shop.stateCode})'}', style: const pw.TextStyle(fontSize: 8)),
          ]),
        ),
        pw.SizedBox(height: 6),
        pw.Table(
          border: pw.TableBorder.all(width: 0.5),
          columnWidths: {
            0: const pw.FixedColumnWidth(18),
            1: const pw.FlexColumnWidth(3),
            2: const pw.FixedColumnWidth(45),
            3: const pw.FixedColumnWidth(48),
            4: const pw.FixedColumnWidth(40),
            5: const pw.FixedColumnWidth(28),
            6: const pw.FixedColumnWidth(28),
            7: const pw.FixedColumnWidth(38),
            8: const pw.FixedColumnWidth(30),
            9: const pw.FixedColumnWidth(45),
            10: const pw.FixedColumnWidth(28),
            11: const pw.FixedColumnWidth(40),
            12: const pw.FixedColumnWidth(40),
            13: const pw.FixedColumnWidth(48),
          },
          children: [
            pw.TableRow(decoration: const pw.BoxDecoration(color: PdfColors.grey300), children: ['#','Product','HSN','Batch','Exp','Qty','Free','Rate','Disc%','Taxable','GST%','CGST','SGST','Amount'].map(h).toList()),
            ...items.asMap().entries.map((e) {
              final i = e.value;
              return pw.TableRow(children: [
                c('${e.key + 1}'),
                c(i['product_name'] as String? ?? ''),
                c(i['hsn'] as String? ?? ''),
                c(i['batch_no'] as String? ?? ''),
                c(i['expiry'] as String? ?? ''),
                c(_n(i['qty']), align: pw.Alignment.centerRight),
                c(_n(i['free_qty']), align: pw.Alignment.centerRight),
                c(_n(i['rate']), align: pw.Alignment.centerRight),
                c(_n(i['discount_pct']), align: pw.Alignment.centerRight),
                c(_n(i['taxable']), align: pw.Alignment.centerRight),
                c(_n(i['gst_rate']), align: pw.Alignment.centerRight),
                c(_n(i['cgst']), align: pw.Alignment.centerRight),
                c(_n(i['sgst']), align: pw.Alignment.centerRight),
                c(_n(i['amount']), align: pw.Alignment.centerRight),
              ]);
            }),
          ],
        ),
        pw.SizedBox(height: 8),
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, child: pw.SizedBox(
          width: 240,
          child: pw.Column(children: [
            _tot('Subtotal', inv['subtotal']),
            _tot('Discount', inv['discount']),
            _tot('Taxable Value', inv['taxable']),
            if (isIgst) _tot('IGST', inv['igst']) else ...[
              _tot('CGST', inv['cgst']),
              _tot('SGST', inv['sgst']),
            ],
            pw.Divider(thickness: 0.7),
            _tot('Invoice Total', inv['total'], bold: true),
          ]),
        )),
        pw.SizedBox(height: 6),
        pw.Text('Amount in words: ${_words((inv['total'] as num).toDouble())}', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 10),
        pw.Container(
          padding: const pw.EdgeInsets.all(4),
          decoration: pw.BoxDecoration(border: pw.Border.all(width: 0.5), color: PdfColors.grey100),
          child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.center, children: [
            pw.Text('For queries: ', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
            pw.Text('${Contact.email}  •  ${Contact.phone}', style: const pw.TextStyle(fontSize: 8)),
          ]),
        ),
        pw.SizedBox(height: 20),
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Text('Goods once sold will not be taken back.\nSubject to ${Shop.stateName} jurisdiction.', style: const pw.TextStyle(fontSize: 7)),
          pw.Column(children: [
            pw.Text('For ${Shop.name}', style: const pw.TextStyle(fontSize: 8)),
            pw.SizedBox(height: 24),
            pw.Text('Authorised Signatory', style: const pw.TextStyle(fontSize: 8)),
          ]),
        ]),
      ],
    ));
    return doc;
  }

  static String _n(Object? v) => v == null ? '' : (v as num).toDouble().toStringAsFixed(2);
  static pw.Widget _tot(String label, Object? v, {bool bold = false}) => pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 1),
      child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        pw.Text(label, style: pw.TextStyle(fontSize: 8, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
        pw.Text(_n(v), style: pw.TextStyle(fontSize: 8, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
      ]));

  static String _words(double amt) {
    final n = amt.round();
    if (n == 0) return 'Zero Rupees Only';
    const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
    const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    String two(int x) => x < 20 ? ones[x] : '${tens[x ~/ 10]}${x % 10 > 0 ? ' ${ones[x % 10]}' : ''}';
    String three(int x) => x >= 100 ? '${ones[x ~/ 100]} Hundred${x % 100 > 0 ? ' ${two(x % 100)}' : ''}' : two(x);
    final parts = <String>[];
    final crore = n ~/ 10000000; final lakh = (n ~/ 100000) % 100;
    final thou  = (n ~/ 1000) % 100; final rest = n % 1000;
    if (crore > 0) parts.add('${three(crore)} Crore');
    if (lakh  > 0) parts.add('${two(lakh)} Lakh');
    if (thou  > 0) parts.add('${two(thou)} Thousand');
    if (rest  > 0) parts.add(three(rest));
    return '${parts.join(' ')} Rupees Only';
  }
}