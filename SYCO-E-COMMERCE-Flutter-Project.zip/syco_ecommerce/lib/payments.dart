import 'package:flutter/material.dart';
import 'db.dart';

class Payments {
  static Future<void> add({required String party, required String type, required double amount, required String mode}) async {
    final d = await DB.db;
    await d.insert('payments', {'party_name': party.trim(), 'date': DateTime.now().toIso8601String(), 'type': type, 'amount': amount, 'mode': mode});
  }

  static Future<List<Map<String, Object?>>> ledgerSummary() async {
    final d = await DB.db;
    final parties = await d.rawQuery('SELECT DISTINCT party_name FROM (SELECT party_name FROM invoices UNION SELECT party_name FROM payments) WHERE party_name IS NOT NULL AND party_name <> "" ORDER BY party_name');
    final out = <Map<String, Object?>>[];
    for (final p in parties) {
      final data = await partyLedger(p['party_name'] as String);
      out.add({'party': p['party_name'], 'outstanding': data['outstanding'], 'aging': data['aging']});
    }
    return out;
  }

  static Future<Map<String, dynamic>> partyLedger(String party) async {
    final d = await DB.db;
    final invoices = await d.query('invoices', where: 'party_name=?', whereArgs: [party], orderBy: 'date ASC');
    final payments = await d.query('payments', where: 'party_name=?', whereArgs: [party], orderBy: 'date ASC');

    final entries = <Map<String, dynamic>>[];
    for (final inv in invoices) {
      final isSale = inv['type'] == 'sale';
      entries.add({'date': inv['date'], 'desc': '${isSale ? 'Sale' : 'Purchase'} ${inv['invoice_no']}', 'debit': isSale ? (inv['total'] as num).toDouble() : 0.0, 'credit': isSale ? 0.0 : (inv['total'] as num).toDouble()});
    }
    for (final pay in payments) {
      final isReceipt = pay['type'] == 'receipt';
      entries.add({'date': pay['date'], 'desc': '${isReceipt ? 'Receipt' : 'Payment'} ${pay['mode'] ?? ''}', 'debit': isReceipt ? 0.0 : (pay['amount'] as num).toDouble(), 'credit': isReceipt ? (pay['amount'] as num).toDouble() : 0.0});
    }
    entries.sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));

    double balance = 0;
    for (final e in entries) { balance += (e['debit'] as double) - (e['credit'] as double); e['balance'] = balance; }

    final openInvoices = <Map<String, dynamic>>[];
    for (final inv in invoices.where((i) => i['type'] == 'sale')) {
      openInvoices.add({'date': DateTime.parse(inv['date'] as String), 'total': (inv['total'] as num).toDouble(), 'no': inv['invoice_no']});
    }
    openInvoices.sort((a, b) => (a['date'] as DateTime).compareTo(b['date'] as DateTime));

    double available = payments.where((p) => p['type'] == 'receipt').fold(0.0, (a, p) => a + (p['amount'] as num).toDouble());
    for (final inv in openInvoices) {
      final applied = available >= (inv['total'] as double) ? (inv['total'] as double) : available;
      inv['unpaid'] = (inv['total'] as double) - applied;
      available -= applied;
      if (available < 0) available = 0;
    }

    final now = DateTime.now();
    final aging = <String, double>{'0-30': 0, '31-60': 0, '61-90': 0, '90+': 0};
    for (final inv in openInvoices) {
      final unpaid = inv['unpaid'] as double;
      if (unpaid <= 0.01) continue;
      final days = now.difference(inv['date'] as DateTime).inDays;
      final key = days <= 30 ? '0-30' : days <= 60 ? '31-60' : days <= 90 ? '61-90' : '90+';
      aging[key] = (aging[key] ?? 0) + unpaid;
    }

    return {'entries': entries, 'outstanding': balance, 'aging': aging};
  }
}

class PaymentDialog extends StatefulWidget {
  const PaymentDialog({super.key});
  @override
  State<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends State<PaymentDialog> {
  final _party = TextEditingController();
  final _amount = TextEditingController();
  String _type = 'receipt';
  String _mode = 'Cash';

  Future<void> _save() async {
    final amt = double.tryParse(_amount.text) ?? 0;
    if (_party.text.trim().isEmpty || amt <= 0) return;
    await Payments.add(party: _party.text, type: _type, amount: amt, mode: _mode);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext c) => AlertDialog(
    title: const Text('Record Payment/Receipt'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      SegmentedButton<String>(segments: const [ButtonSegment(value: 'receipt', label: Text('Receipt')), ButtonSegment(value: 'payment', label: Text('Payment'))], selected: {_type}, onSelectionChanged: (s) => setState(() => _type = s.first)),
      TextField(controller: _party, decoration: const InputDecoration(labelText: 'Party name')),
      TextField(controller: _amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount')),
      DropdownButtonFormField<String>(value: _mode, items: const ['Cash', 'UPI', 'Bank'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(), onChanged: (v) => setState(() => _mode = v!)),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: _save, child: const Text('Save'))],
  );
}